﻿local L = LibStub("AceLocale-3.0"):NewLocale("HudMap", "ruRU")
if not L then return end

L["Bastion of Twilight"] = "Сумеречный бастион"
-- L["Beth'tilac"] = ""
L["Blackwing Descent"] = "Твердыня Крыла Тьмы"
L["Caustic Slime Range"] = "Радиус \"Едкой слизи\""
L["Chimaeron"] = "Химерон"
L["Cho'Gall"] = "Чо'Галл"
-- L["Crystal Trap Duration"] = ""
-- L["Firelands"] = ""
-- L["Immolation Trap Duration"] = ""
-- L["Majordomo Staghelm"] = ""
L["Maloriak"] = "Малориак"
L["Omnotron Defense System"] = "Защитная система \"Омнитрон\""
-- L["Shannox"] = ""
L["Sinestra"] = "Синестра"
L["Twilight Ascendant Council"] = "Совет Перерожденных"
L["Valiona and Theralion"] = "Валиона и Тералион"
L["Worship Radius"] = "Радиус \"Поклонения\""
L["Wrack"] = "Смятие"
L["Wrack End"] = "Смятие Закончилось!"
L["Wrack Radius"] = "Радиус Смятие" -- Needs review
L["Wrack Start"] = "Смятие Началось!"
