﻿local L = LibStub("AceLocale-3.0"):NewLocale("HudMap", "deDE")
if not L then return end

L["Bastion of Twilight"] = "Bastion des Zwielichts" -- Needs review
-- L["Beth'tilac"] = ""
L["Blackwing Descent"] = "Pechschwingenabstieg" -- Needs review
L["Caustic Slime Range"] = "Ätzender Schleim Reichweite" -- Needs review
L["Chimaeron"] = "Schimaeron" -- Needs review
L["Cho'Gall"] = "Cho'gall" -- Needs review
-- L["Crystal Trap Duration"] = ""
-- L["Firelands"] = ""
-- L["Immolation Trap Duration"] = ""
-- L["Majordomo Staghelm"] = ""
L["Maloriak"] = "Maloriak" -- Needs review
L["Omnotron Defense System"] = "Omnotron Verteidigungssystem" -- Needs review
-- L["Shannox"] = ""
-- L["Sinestra"] = ""
L["Twilight Ascendant Council"] = "Rat der Aszendentfürsten" -- Needs review
L["Valiona and Theralion"] = "Valiona & Theralion" -- Needs review
-- L["Worship Radius"] = ""
-- L["Wrack"] = ""
-- L["Wrack End"] = ""
-- L["Wrack Radius"] = ""
-- L["Wrack Start"] = ""
